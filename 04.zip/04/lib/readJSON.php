<?php
function readJSON($filename) {
    $jsonString = file_get_contents($filename);
    $data = json_decode($jsonString, true);
    return $data;
}
?>
