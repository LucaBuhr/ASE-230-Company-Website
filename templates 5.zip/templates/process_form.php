<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $comments = $_POST['comments'];
    
    $data = "Name: $name\nEmail: $email\nSubject: $subject\nMessage: $comments\n\n";
    
    $dataFilePath = 'contact_data/contact_requests.txt';
    
    if (file_put_contents($dataFilePath, $data, FILE_APPEND | LOCK_EX) !== false) {
        echo 'Message sent successfully!';
    } else {
        echo 'Message could not be saved.';
    }
} else {
    echo 'Invalid request.';
}
?>
